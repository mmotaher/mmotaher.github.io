function toFahrenheit(celcius) {
  if (Number(celcius) === NaN || !celsius) {
    return;
  }
  
  return (celcius * 9/5) + 32;
}

